#!/usr/bin/env python3
import json
import os
import glob
import re
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
EXPECTED = {
    'super_easy.json': 'super_easy_',
    'easy.json': 'easy_',
    'medium.json': 'medium_',
    'hard.json': 'hard_',
    'super_hard.json': 'super_hard_',
    'insane.json': 'insane_',
}

errors = []
all_ids = set()
all_questions = {}
total = 0

for filename, prefix in EXPECTED.items():
    path = os.path.join(BASE, filename)
    if not os.path.exists(path):
        errors.append(f'{filename}: arquivo ausente')
        continue

    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except Exception as exc:
        errors.append(f'{filename}: JSON inválido: {exc}')
        continue

    if len(data) != 100:
        errors.append(f'{filename}: esperado 100 perguntas, encontrado {len(data)}')

    total += len(data)
    expected_ids = {f'{prefix}{i:03d}' for i in range(1, 101)}
    found_ids = {q.get('id') for q in data}
    missing = expected_ids - found_ids
    extra = found_ids - expected_ids
    if missing:
        errors.append(f'{filename}: IDs ausentes: {sorted(missing)}')
    if extra:
        errors.append(f'{filename}: IDs inesperados: {sorted(extra)}')

    for pos, q in enumerate(data, 1):
        qid = q.get('id', f'posição {pos}')
        if qid in all_ids:
            errors.append(f'{filename}: ID duplicado global: {qid}')
        all_ids.add(qid)

        for field in ('id', 'category', 'question', 'options', 'correct'):
            if field not in q:
                errors.append(f'{filename}/{qid}: campo ausente: {field}')

        if not isinstance(q.get('category'), str) or not q.get('category', '').strip():
            errors.append(f'{filename}/{qid}: categoria inválida')
        if not isinstance(q.get('question'), str) or not q.get('question', '').strip():
            errors.append(f'{filename}/{qid}: enunciado inválido')

        opts = q.get('options')
        if not isinstance(opts, list) or len(opts) != 4:
            errors.append(f'{filename}/{qid}: esperado exatamente 4 alternativas')
            continue
        normalized = [str(x).strip().casefold() for x in opts]
        if any(not x for x in normalized):
            errors.append(f'{filename}/{qid}: alternativa vazia')
        if len(set(normalized)) != 4:
            errors.append(f'{filename}/{qid}: alternativas duplicadas')

        correct = q.get('correct')
        if not isinstance(correct, int) or not 0 <= correct <= 3:
            errors.append(f'{filename}/{qid}: índice correct inválido: {correct!r}')

        text_key = re.sub(r'\s+', ' ', q.get('question', '').strip().casefold())
        if text_key in all_questions:
            errors.append(f'{filename}/{qid}: enunciado duplicado de {all_questions[text_key]}')
        else:
            all_questions[text_key] = qid

    dist = Counter(q['correct'] for q in data if isinstance(q.get('correct'), int))
    cats = Counter(q.get('category') for q in data)
    print(f'{filename:20} {len(data):3} perguntas | respostas A/B/C/D = '
          f"{dist.get(0,0)}/{dist.get(1,0)}/{dist.get(2,0)}/{dist.get(3,0)} | "
          f'{len(cats)} categorias')

print('-' * 80)
print(f'TOTAL: {total} perguntas')

if errors:
    print('\nERROS:')
    for err in errors:
        print(' -', err)
    raise SystemExit(1)

print('VALIDAÇÃO OK: estrutura compatível, 600 IDs únicos e nenhuma pergunta duplicada.')
